from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///data.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class Employee(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)

    def __repr__(self):
        return f'<Employee {self.name}>'

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        employee_name = request.form.get('name')
        if employee_name:
            new_employee = Employee(name=employee_name)
            db.session.add(new_employee)
            db.session.commit()
            return redirect(url_for('index'))

    employees = Employee.query.all()
    return render_template('index.html', employees=employees)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
